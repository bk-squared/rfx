"""Ring-down settling witness (``settling_db``) on every S-matrix lane.

The CLAUDE.md rule made mechanical: an S-parameter record must be long enough
that the port fields have rung down by -40 dB from their peak, otherwise the
single-bin DFTs are truncation artifacts and look like ordinary (bad)
S-parameters. One file for the whole witness (tier 3b of the 2026-09
test-corpus reorganisation, see
``docs/design_notes/20260903_test_reorg_tier3b_consolidation.md``). Sections,
each formerly its own file:

1. MSL lane (``compute_msl_s_matrix``) — was ``test_msl_settling_witness.py``.
   Root cause this guards (measured, PR #462 Sheen-1990 study, dx=200 um):
   a fixed num_periods=20 record ended while the LPF stopband was still
   ringing, and the truncated single-bin DFTs produced |S| column-power poles
   up to ~1.8e3 — 58/120 non-passive bins — that shrank monotonically with
   record length (20->60 periods: worst pole 62->8.8) while absorber depth
   (8->24 CPML layers) did not move them. Two tiny thru-line FDTD runs
   (~seconds each): a deliberately truncated record must fail the witness
   loudly, a settled record must pass silently.
2. Enforcement of the -40 dB bar (issue #662) — was
   ``test_settling_witness_enforcement.py``. The witness and its threshold
   were both already written down; what was missing on two lanes was the
   comparison between them. Measured BEFORE the fix (``compute_coaxial_two_port``,
   the coax through-line fixture of ``tests/unit/sparams/test_coax_two_port_smatrix.py``,
   JAX_PLATFORMS=cpu)::

       n_steps=  400  settling_db=[ -6.84,  -6.93]  warnings emitted: 0
       n_steps=  700  settling_db=[-28.15, -29.46]  warnings emitted: 0
       n_steps= 1500  settling_db=[-43.97, -44.53]  warnings emitted: 0
       n_steps= 3000  settling_db=[-67.26, -68.09]  warnings emitted: 0
       n_steps= 6000  settling_db=[-65.87, -65.59]  warnings emitted: 0

   The 400- and 700-step rows violate the bar by 33 and 12 dB and returned a
   plausible-looking ``s_params`` in total silence. Split per this repo's
   physics-run discipline: FAST (no FDTD) — the warner's own decision logic
   plus a static governance gate that every ``settling_db``-producing lane
   routes through the ONE shared warner; SLOW (``slow_physics``, real FDTD) —
   the end-to-end firing pair on the silent lane.
3. Waveguide lane (#538, ``compute_waveguide_s_matrix``) — was
   ``test_waveguide_settling_witness.py``. The witness is pure host-side
   post-processing of the ``v_probe_t`` records the scan already produces
   for the DFT extraction — nothing is added to the jitted graph, so S
   cannot be perturbed; the identity test pins that structurally-guaranteed
   property anyway. Fixture is the WR-90-class two-port straight guide from
   ``test_waveguide_geometry_hygiene``, deliberately short records so the
   truncation warning path is exercised for real.

The consolidation preserved the original assertions and thresholds. The
MSL fixture subsequently gained its missing explicit ground under #729;
CPML padding does not supply a ground conductor.
"""

from __future__ import annotations

import ast
import math
import pathlib
import warnings

import jax.numpy as jnp
import numpy as np
import pytest

from rfx import Box, Simulation
from rfx.api._sparams import _SETTLING_WITNESS_DB, _warn_if_ringdown_truncated
from tests._realized_geometry import assert_sheet_planes, assert_wall_planes


# ===========================================================================
# 1. MSL lane (formerly test_msl_settling_witness.py)
# ===========================================================================

def _msl_thru(domain_y=0.008, y_c=0.004):
    sim = Simulation(freq_max=20e9, domain=(0.012, domain_y, 0.0032),
                     dx=2e-4, boundary="cpml", cpml_layers=8)
    sim.add_material("sub", eps_r=2.2)
    sim.add(Box((0, 0, 0), (0.012, domain_y, 0.0008)), material="sub")
    sim.add(Box((0, 0, 0), (0.012, domain_y, 0)), material="pec")
    # 35 um foil: a SHEET (#931 §1.3), declared by a zero-thickness Box
    # on the laminate top. h_sub / dx = 0.8 mm / 0.2 mm = 4, so the substrate face is a
    # node line and the sheet lands on it exactly. Drawn one cell thick
    # before the contract, it would now be a VOLUME — walls at BOTH z
    # faces and the Ez edge between them shorted.
    sim.add(Box((0.0, y_c - 0.0006, 0.0008),
                (0.012, y_c + 0.0006, 0.0008)), material="pec")
    sim.add_msl_port(position=(0.002, y_c, 0.0), width=0.0012, height=0.0008,
                     direction="+x", impedance=50.0, eps_r_sub=2.2, name="p1")
    sim.add_msl_port(position=(0.010, y_c, 0.0), width=0.0012, height=0.0008,
                     direction="-x", impedance=50.0, eps_r_sub=2.2, name="p2")
    return sim


_MSL_FREQS = jnp.linspace(2e9, 18e9, 12)


def test_truncated_record_fails_the_witness_loudly():
    sim = _msl_thru()
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        res = sim.compute_msl_s_matrix(freqs=_MSL_FREQS, num_periods=2.0)

    assert res.settling_db is not None and res.settling_db.shape == (2,)
    assert np.all(np.isfinite(res.settling_db))
    # A 2-period record ends essentially at the transit peak.
    assert np.all(res.settling_db > -40.0)

    witness = [w for w in caught if "settling witness" in str(w.message)]
    assert witness, "a truncated record must warn, not just return numbers"
    msg = str(witness[0].message)
    # The warning must carry the measured value and the actionable knob.
    assert "num_periods" in msg and "-40" in msg
    assert "settling_db" in msg


def test_settled_record_passes_the_witness_silently():
    sim = _msl_thru()
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        res = sim.compute_msl_s_matrix(freqs=_MSL_FREQS, num_periods=40.0)

    assert res.settling_db is not None
    # A matched thru rings down fast; the witness must be deeply settled,
    # not merely under the line (guards against a witness that measures
    # the wrong window and hovers near the threshold).
    assert np.all(res.settling_db < -60.0), res.settling_db

    assert not [w for w in caught if "settling witness" in str(w.message)]


def test_witness_survives_pre_existing_user_probes():
    """The witness columns are indexed from len(self._probes) at call time; a
    wrong base would silently measure a USER probe and produce a plausible
    settling number — the worst failure class for a witness. Registering a
    user probe first exercises exactly that offset."""
    sim = _msl_thru()
    sim.add_probe(position=(0.006, 0.004, 0.0016), component="ez")
    n_before = len(sim._probes)

    res = sim.compute_msl_s_matrix(freqs=_MSL_FREQS, num_periods=40.0)

    assert len(sim._probes) == n_before, "user probes must survive untouched"
    # A settled thru must still read deeply settled through the offset base.
    assert res.settling_db is not None
    assert np.all(res.settling_db < -60.0), res.settling_db


def test_witness_probes_do_not_leak_into_the_simulation():
    sim = _msl_thru()
    n_probes_before = len(sim._probes)
    sim.compute_msl_s_matrix(freqs=_MSL_FREQS, num_periods=2.0)
    assert len(sim._probes) == n_probes_before


def test_result_field_is_optional_for_backward_compatibility():
    from rfx import MSLSMatrixResult

    legacy = MSLSMatrixResult(
        S=np.zeros((2, 2, 3), dtype=complex),
        freqs=np.array([1e9, 2e9, 3e9]),
        Z0=np.zeros((2, 3), dtype=complex),
        beta=np.zeros(3, dtype=complex),
    )
    assert legacy.settling_db is None


# ===========================================================================
# 2. Enforcement of the -40 dB bar (issue #662; formerly
#    test_settling_witness_enforcement.py)
# ===========================================================================

_SPARAMS_SRC = pathlib.Path(
    __import__("rfx.api._sparams", fromlist=["_sparams"]).__file__
)
_EXECUTE_SRC = pathlib.Path(
    __import__("rfx.api._execute", fromlist=["_execute"]).__file__
)


def _catch(fn):
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        fn()
    return [w for w in caught if "settling witness" in str(w.message)]


# ---------------------------------------------------------------------------
# FAST — the warner's decision logic
# ---------------------------------------------------------------------------

def test_threshold_constant_is_the_documented_bar():
    """One shared constant, and it is the -40 dB the docstrings quote."""
    assert _SETTLING_WITNESS_DB == -40.0


def test_violating_witness_warns_and_quotes_the_measured_value():
    hot = _catch(lambda: _warn_if_ringdown_truncated(
        np.array([-1.1, -55.0]), ("feed", "load"), n_steps=700))
    assert len(hot) == 1, "one aggregate warning per call, not one per drive"
    msg = str(hot[0].message)
    # The measured value, the bar, the field to inspect, and the knob.
    assert "-1.1 dB" in msg, msg
    assert "-40" in msg and "settling_db" in msg, msg
    assert "n_steps=700" in msg, msg


def test_settled_witness_stays_silent():
    """Control: a check that fires on everything is worse than one that fires
    on nothing. A settled record must produce no warning at all."""
    assert _catch(lambda: _warn_if_ringdown_truncated(
        np.array([-67.26, -68.09]), ("port1", "port2"), n_steps=3000)) == []


def test_witness_exactly_at_the_bar_is_not_a_violation():
    """The bar is documented as "above -40 dB"; equality must not fire (an
    off-by-one here would make the control test above fixture-dependent)."""
    assert _catch(lambda: _warn_if_ringdown_truncated(
        np.array([-40.0, -40.0]), ("a", "b"), n_steps=1)) == []
    assert len(_catch(lambda: _warn_if_ringdown_truncated(
        np.array([-39.9, -80.0]), ("a", "b"), n_steps=1))) == 1


def test_all_nan_witness_is_silent_not_a_false_fire():
    """NaN is a DESIGNED state, not a failure: the differentiable lanes leave
    ``settling_db`` NaN because the witness needs a concrete time series. A
    naive ``settling_db > -40`` would evaluate NaN comparisons; this pins that
    the finite mask, not luck, is what keeps those lanes quiet."""
    assert _catch(lambda: _warn_if_ringdown_truncated(
        np.full(2, np.nan), ("port1", "port2"), n_steps=400)) == []


def test_nan_beside_a_violator_does_not_mask_the_violator():
    """The other half of the NaN decision: a partially-concrete array must
    still report its concrete violator (``np.nanmax``-style silence here would
    be a real regression, and a plain ``np.max`` would return NaN and fire
    never)."""
    hot = _catch(lambda: _warn_if_ringdown_truncated(
        np.array([np.nan, -2.0]), ("port1", "port2"), n_steps=400))
    assert len(hot) == 1
    assert "port port2 driven: -2.0 dB" in str(hot[0].message)
    assert "port1" not in str(hot[0].message)


def test_every_violating_drive_is_named_not_only_the_worst():
    """Record length is a per-drive property with a per-drive remedy; naming
    only the worst drive would hide a second one needing the same fix."""
    hot = _catch(lambda: _warn_if_ringdown_truncated(
        np.array([-1.0, -30.0, -70.0]), ("p1", "p2", "p3"), n_steps=400))
    assert len(hot) == 1
    msg = str(hot[0].message)
    assert "port p1 driven: -1.0 dB" in msg and "port p2 driven: -30.0 dB" in msg
    assert "p3" not in msg, "a settled drive must not be named"


def test_warning_names_the_knob_the_lane_is_actually_driven_by():
    """One warning shape, two record-length knobs: the waveguide/MSL/mixed
    lanes are driven by ``num_periods``, the coax lanes by ``n_steps``. Naming
    the wrong one makes the remedy un-actionable."""
    by_periods = str(_catch(lambda: _warn_if_ringdown_truncated(
        np.array([-1.0]), ("p1",), num_periods=2.0))[0].message)
    assert "num_periods=2" in by_periods and "Increase num_periods" in by_periods
    by_steps = str(_catch(lambda: _warn_if_ringdown_truncated(
        np.array([-1.0]), ("p1",), n_steps=400))[0].message)
    assert "n_steps=400" in by_steps and "Increase n_steps" in by_steps


# ---------------------------------------------------------------------------
# FAST — governance: one warner, wired to every producer
# ---------------------------------------------------------------------------

def _functions_producing_settling_db():
    """(name, routes_through_warner) for every function that attaches a
    ``settling_db=`` to a result object.

    Two modules do so: ``_sparams.py`` (the S-matrix lanes) and, since #885,
    ``_execute.py`` (the ``run()`` lane, which attaches the witness to
    ``Result``). ``_spec.py`` only declares the field. The scan was widened
    with the second module the moment it appeared, per the instruction the
    first version of this docstring left for exactly that case.
    """
    out = []
    for src in (_SPARAMS_SRC, _EXECUTE_SRC):
        out.extend(_producers_in(ast.parse(src.read_text(encoding="utf-8"))))
    return out


def _producers_in(tree):
    out = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        produces = any(
            isinstance(sub, ast.Call)
            and any(kw.arg == "settling_db" for kw in sub.keywords)
            for sub in ast.walk(node)
        )
        if not produces:
            continue
        routed = any(
            isinstance(sub, ast.Call)
            and isinstance(sub.func, ast.Name)
            and sub.func.id == "_warn_if_ringdown_truncated"
            for sub in ast.walk(node)
        )
        out.append((node.name, routed))
    return out


def test_every_settling_db_producer_routes_through_the_shared_warner():
    """The #662 defect in structural form.

    RED on the unfixed tree: ``compute_coaxial_two_port`` and
    ``compute_coax_msl_transition`` both attach a ``settling_db`` they never
    compare to the bar. A new lane that copies that pattern fails here rather
    than shipping another silent witness.
    """
    producers = _functions_producing_settling_db()
    assert producers, "AST probe found no settling_db producers — it has rotted"
    silent = sorted(name for name, routed in producers if not routed)
    assert not silent, (
        f"lane(s) {silent} attach a settling_db that is never compared to "
        f"{_SETTLING_WITNESS_DB:g} dB — call _warn_if_ringdown_truncated() "
        "there (issue #662)."
    )


def test_the_known_lanes_are_all_covered():
    """Companion to the gate above: pins WHICH lanes carry the witness, so a
    lane silently losing its witness entirely (producer disappears -> the gate
    above passes vacuously for it) is also caught."""
    names = {name for name, _ in _functions_producing_settling_db()}
    assert {
        "compute_waveguide_s_matrix",
        "compute_msl_s_matrix",
        "compute_mixed_s_matrix",
        "compute_coaxial_two_port",
        "compute_coax_msl_transition",
        "_attach_run_settling_witness",
    } <= names, sorted(names)


# ---------------------------------------------------------------------------
# SLOW — end-to-end on the lane that was silent (real FDTD, ~60 s total)
# ---------------------------------------------------------------------------

_BAND = np.array([4.0e9, 6.0e9, 8.0e9, 10.0e9, 12.0e9])


def _coax_two_port_sim():
    """The committed through-line fixture from
    tests/unit/sparams/test_coax_two_port_smatrix.py (domain 8x8x60 mm,
    freq_max 40 GHz)."""
    from rfx.api import Simulation
    from rfx.sources.sources import GaussianPulse

    sim = Simulation(domain=(0.008, 0.008, 0.060), freq_max=40.0e9,
                     boundary="cpml")
    sim.add_coaxial_port((0.004, 0.004, 0.020), face="top", pin_length=5.0e-3,
                         waveform=GaussianPulse(f0=8.0e9, bandwidth=1.2))
    return sim


@pytest.mark.slow_physics
def test_underrun_coax_two_port_warns_instead_of_returning_it_quietly():
    """Deliberately under-run record: measured settling_db [-6.84, -6.93] dB
    on this fixture at n_steps=400, i.e. 33 dB past the bar. On the unfixed
    tree this returned a finite, ordinary-looking s_params and zero warnings.
    """
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        res = _coax_two_port_sim().compute_coaxial_two_port(
            n_steps=400, freqs=_BAND)

    sd = np.asarray(res.settling_db)
    assert sd.shape == (2,) and np.all(np.isfinite(sd)), sd
    assert np.all(sd > _SETTLING_WITNESS_DB), (
        f"fixture no longer under-run (settling_db={sd}); it cannot witness "
        "the truncation warning any more — shorten the record."
    )
    hot = [w for w in caught if "settling witness" in str(w.message)]
    assert hot, (
        f"settling_db={sd} violates the {_SETTLING_WITNESS_DB:g} dB bar and "
        "nothing warned (issue #662)"
    )
    msg = str(hot[0].message)
    assert "port port1 driven" in msg and "port port2 driven" in msg, msg
    assert "n_steps=400" in msg and "settling_db" in msg, msg


@pytest.mark.slow_physics
def test_settled_coax_two_port_stays_silent():
    """Control on the SAME fixture: measured [-67.26, -68.09] dB at
    n_steps=3000. A settled run must not warn."""
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        res = _coax_two_port_sim().compute_coaxial_two_port(
            n_steps=3000, freqs=_BAND)

    sd = np.asarray(res.settling_db)
    assert np.all(sd < -60.0), (
        f"settled control drifted to {sd}; it no longer sits well clear of "
        "the bar, so its silence would stop meaning anything."
    )
    assert not [w for w in caught if "settling witness" in str(w.message)]


@pytest.mark.slow_physics
def test_differentiable_coax_path_leaves_the_witness_nan_and_silent():
    """The NaN path end-to-end: the ``eps_scale`` lane cannot build the
    witness (it would need a concrete time series), leaves settling_db NaN by
    design, and must therefore stay silent even though the SAME 400-step
    record fires the warning on the concrete lane above."""
    import jax.numpy as jnp

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        res = _coax_two_port_sim().compute_coaxial_two_port(
            n_steps=400, freqs=_BAND, eps_scale=jnp.asarray(1.0))

    sd = np.asarray(res.settling_db)
    assert sd.shape == (2,) and np.all(np.isnan(sd)), sd
    assert not [w for w in caught if "settling witness" in str(w.message)]


# ===========================================================================
# 3. Waveguide lane (#538; formerly test_waveguide_settling_witness.py)
# ===========================================================================

_WG_FREQS = np.linspace(8.2e9, 12.4e9, 5)


def _wg_two_port():
    sim = Simulation(freq_max=float(_WG_FREQS[-1]), domain=(0.12, 0.04, 0.02),
                     dx=0.004, boundary="cpml", cpml_layers=10)
    for x, direction in ((0.02, "+x"), (0.10, "-x")):
        sim.add_waveguide_port(
            x, direction=direction, mode=(1, 0), mode_type="TE",
            freqs=jnp.asarray(_WG_FREQS), f0=float(np.mean(_WG_FREQS)),
            bandwidth=0.6,
        )
    return sim


def test_settling_populated_and_truncation_warning_fires():
    """All three normalize modes populate settling_db (n_ports,), finite;
    a deliberately short record fires the aggregate truncation warning
    (measured 2026-08-09, worst-of-4-series witness: [-2.3, -1.9] dB at
    num_periods=4.0 — the parameter this test runs — on this
    fixture — far above the -40 dB rule, which is the point)."""
    for mode in (False, True, "flux"):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            res = _wg_two_port().compute_waveguide_s_matrix(
                normalize=mode, num_periods=4.0)
        sd = res.settling_db
        assert sd is not None and sd.shape == (2,), (mode, sd)
        assert np.all(np.isfinite(sd)), (mode, sd)
        assert np.all(sd < 0.0), (mode, sd)
        assert any("ringing" in str(w.message) for w in caught), (
            f"normalize={mode!r}: truncation warning did not fire on an "
            f"unsettled record (settling_db={sd})")


def test_longer_record_settles_deeper():
    """Direction sanity: more periods -> more negative witness on the same
    fixture (the falsifier for a witness that reads something other than
    ring-down)."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        short = _wg_two_port().compute_waveguide_s_matrix(num_periods=4.0)
        long_ = _wg_two_port().compute_waveguide_s_matrix(num_periods=16.0)
    assert float(np.max(long_.settling_db)) < float(np.max(short.settling_db)), (
        short.settling_db, long_.settling_db)


def test_witness_flag_does_not_perturb_s_extractor_level():
    """Direct non-perturbation pair at the extractor level (review round-1
    upgrade over a determinism-only pin): the SAME cfgs list driven with
    return_settling False vs True must return bit-identical S — the flag
    gates only host-side post-processing of records the scan already
    produces. Fixture imitates
    test_simulation.py::test_extract_waveguide_s_matrix_two_port_reciprocity."""
    from rfx.core.yee import init_materials
    from rfx.sources.waveguide_port import (
        WaveguidePort, init_waveguide_port, extract_waveguide_s_matrix,
    )
    # reuse the committed reciprocity fixture's grid helper directly
    # (package-form import since the tier-4b move; sibling is in tests/unit/runners)
    import os
    import sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from tests.unit.runners.test_simulation import _CompiledWgGrid as _Grid

    a_wg, b_wg, length, dx, nc, f0 = 0.04, 0.02, 0.12, 0.002, 10, 6e9
    grid = _Grid(length, a_wg, b_wg, dx, nc)
    materials = init_materials(grid.shape)
    freqs = jnp.linspace(5.0e9, 7.0e9, 5)
    n_steps = grid.num_timesteps(num_periods=8)

    def _port(x_index, direction):
        return WaveguidePort(
            x_index=x_index, y_slice=(0, grid.ny), z_slice=(0, grid.nz),
            a=(grid.ny - 1) * dx, b=(grid.nz - 1) * dx,
            mode=(1, 0), mode_type="TE", direction=direction,
        )

    cfgs = [
        init_waveguide_port(_port(nc + 5, "+x"), dx, freqs, f0=f0,
                            dft_total_steps=n_steps),
        init_waveguide_port(_port(grid.nx - nc - 6, "-x"), dx, freqs, f0=f0,
                            dft_total_steps=n_steps),
    ]
    s_off = extract_waveguide_s_matrix(
        grid, materials, cfgs, n_steps,
        boundary="cpml", cpml_axes="x", pec_axes="yz",
    )
    s_on, settling = extract_waveguide_s_matrix(
        grid, materials, cfgs, n_steps,
        boundary="cpml", cpml_axes="x", pec_axes="yz", return_settling=True,
    )
    assert np.array_equal(np.asarray(s_off), np.asarray(s_on)), (
        "return_settling=True perturbed S at the extractor level")
    assert settling.shape == (2,) and np.all(np.isfinite(settling))
    assert np.all(settling < 0.0)


# ===========================================================================
# 4. Underflowed / subnormal port records (#869)
# ===========================================================================
#
# The witness took its worst end/peak ratio over every port record, including
# records that had fallen off the bottom of float32. Behind a PEC short that
# broke it in BOTH directions, measured by the WR-90 chain battery (VESSL run
# 369367257823, tests/fixtures/waveguide_chain_battery/fixture.json):
#
#   * fine rung (dx = 0.635 mm, 8-cell short): the four far-port records are
#     exactly zero (peak = 0.0, n_nonzero = 0 of 2849), (end+tiny)/(peak+tiny)
#     = 1, and the witness reported 0.00 dB -- a hard fail -- at 40 AND at 80
#     periods, on a run whose signal-carrying records read -99.98 / -101.20 dB
#     and whose S moves by <= 7.3e-6 between the two record lengths.
#   * mid rung (dx = 1.27 mm, 4-cell short): the same records are float32
#     subnormals (peak amplitudes 1.58e-37 .. 2.97e-40) and the witness PASSED
#     at -40.85 / -40.91 dB on the worst of them, 0.9 dB inside the bar, while
#     the signal-carrying records read -94.62 / -94.55 dB.
#   * coarse rung (dx = 2.54 mm): the far-port records are normal float32
#     (peak amplitudes 3.15e-20 / 5.5e-23, tails 5.5e-25 rms). Nothing is
#     skipped and the cell's number must not move.
#
# These tests replay the STORED per-record peak/end pairs through the
# production witness. No FDTD runs here; the battery is a one-run
# pre-declared artifact and is never re-measured.

import json  # noqa: E402

from rfx.sources.waveguide_port import (  # noqa: E402
    _settling_db_for_record,
    _settling_record_floor_amplitude,
    settling_db_from_port_records,
)

_BATTERY_FIXTURE = (pathlib.Path(__file__).resolve().parents[3]
                    / "tests" / "fixtures" / "waveguide_chain_battery"
                    / "fixture.json")


def _battery_cells():
    if not _BATTERY_FIXTURE.exists():  # pragma: no cover - fixture is committed
        pytest.skip(f"{_BATTERY_FIXTURE} not present")
    return json.loads(_BATTERY_FIXTURE.read_text())["cells"]


def _pec_short_cell(rung: str, lane: str) -> dict:
    for c in _battery_cells():
        if c["dut"] == "pec_short" and c["rung"] == rung and c["lane"] == lane:
            return c
    raise AssertionError(f"no pec_short|{rung}|{lane} cell in the fixture")


class _Records:
    """A stand-in for a final ``WaveguidePortConfig``: the witness only reads
    the four record attributes off it."""

    def __init__(self, per_record):
        for name, arr in per_record.items():
            setattr(self, name, arr)


def _rebuild_record(peak_power, end_power, n_steps, dtype=np.float32):
    """A float32 record with the stored peak power and tail-mean power.

    One sample at the peak amplitude, the last tenth (the window the witness
    averages) at the tail rms amplitude, zeros in between -- enough for
    ``p.max()`` and ``p[-tail:].mean()`` to reproduce the stored pair, and it
    round-trips through the same float32 storage the run used, so subnormal
    peaks stay subnormal.
    """
    a = np.zeros(int(n_steps), dtype=dtype)
    if peak_power > 0.0:
        a[0] = dtype(np.sqrt(peak_power))
    tail = max(1, int(n_steps) // 10)
    if end_power > 0.0:
        a[-tail:] = dtype(np.sqrt(end_power))
    return a


def _rebuild_solve(call):
    """Every stored record carries its own ``n_steps``, so the rebuilt arrays
    are the length the run actually recorded (40- and 80-period blocks alike)."""
    by_port: dict[int, dict] = {}
    for r in call:
        by_port.setdefault(r["port_index"], {})[r["record"]] = _rebuild_record(
            r["peak"], r["end"], r["n_steps"])
    return [_Records(by_port[k]) for k in sorted(by_port)]


def _legacy_worst(cfgs):
    """The pre-fix arithmetic, verbatim, for the preserved-verdict control."""
    worst = -np.inf
    for cfg in cfgs:
        for ts in (cfg.v_probe_t, cfg.v_ref_t, cfg.i_probe_t, cfg.i_ref_t):
            ts_np = np.abs(np.asarray(ts, dtype=np.float64))
            p = ts_np ** 2
            tail = max(1, p.shape[0] // 10)
            end = float(p[-tail:].mean())
            peak = float(p.max())
            tiny = float(np.finfo(float).tiny)
            worst = max(worst, 10.0 * np.log10((end + tiny) / (peak + tiny)))
    return float(worst)


def test_floor_is_the_smallest_peak_on_which_the_bar_decision_is_normal():
    """The floor is derived, not chosen: a record sitting exactly at the
    -40 dB bar has a tail whose rms amplitude is 1e-2 of its peak amplitude,
    so requiring that rms to be a NORMAL number puts the peak at
    ``100 * tiny``. Tighten the bar and the floor rises with it."""
    tiny32 = float(np.finfo(np.float32).tiny)
    floor = _settling_record_floor_amplitude(tiny32)
    assert floor == pytest.approx(tiny32 * 10.0 ** (abs(_SETTLING_WITNESS_DB) / 20.0),
                                  rel=0, abs=0)
    assert floor == pytest.approx(1.1754943508222875e-36, rel=1e-15)
    # a record AT the floor, sitting exactly at the bar: tail rms == tiny
    tail_rms = floor * 10.0 ** (_SETTLING_WITNESS_DB / 20.0)
    assert tail_rms == pytest.approx(tiny32, rel=1e-12)
    # and the floor follows the format, not a hard-coded float32 constant:
    # float64 reaches far further down, so under x64 the guard sits far lower
    # and a record that is subnormal in float32 stays witnessable
    assert _settling_record_floor_amplitude(float(np.finfo(np.float64).tiny)) < floor


def test_the_floor_separates_exactly_the_records_whose_tail_is_subnormal():
    """The measured justification, pinned. Over every cell and both record
    lengths of the battery, the floor skips exactly the records whose tail
    mean is subnormal in the format the run stored them in, and keeps every
    record whose tail mean is normal -- no misclassification either way."""
    misfiled = []
    for c in _battery_cells():
        for block in (c, c.get("settling_rerun")):
            if not block:
                continue
            tiny = block["float32_normal_min"]
            floor = _settling_record_floor_amplitude(tiny)
            for ci, call in enumerate(block["settling_records"]):
                for r in call:
                    kept = _settling_db_for_record(r["peak"], r["end"], floor) is not None
                    tail_rms = np.sqrt(r["end"]) if r["end"] > 0 else 0.0
                    tail_normal = tail_rms >= tiny
                    if kept != tail_normal:
                        misfiled.append((c["dut"], c["rung"], c["lane"], ci,
                                         r["record"], r["peak"], r["end"]))
    assert not misfiled, misfiled


def test_underflowed_far_port_records_are_no_longer_scored_as_zero_db():
    """Fine rung, both lanes, both record lengths: the far-port records are
    exactly zero and used to make the witness read 0.00 dB. Skipped now, and
    the run reads what its signal-carrying records say (~ -100 dB at 40
    periods, ~ -114 dB at 80)."""
    for lane in ("false", "flux"):
        c = _pec_short_cell("fine", lane)
        for block in (c, c["settling_rerun"]):
            assert set(block["settling_db"].values()) == {0.0}, (
                "fixture no longer carries the 0 dB reading this guards")
            worst_over_solves = -np.inf
            for call in block["settling_records"]:
                db, detail = settling_db_from_port_records(
                    _rebuild_solve(call), return_detail=True)
                assert db < -90.0, (lane, db, detail)
                assert db != 0.0
                worst_over_solves = max(worst_over_solves, db)
            # the driver wrote this number independently at measurement time,
            # from the same records, before any fix existed
            assert worst_over_solves == pytest.approx(
                block["settling_db_over_normal_records"], rel=1e-6), lane


def test_the_zeroed_records_are_reported_by_name_so_the_caller_sees_the_gap():
    """Skipping silently would trade one blind spot for another: the witness
    must say which records it stopped covering."""
    c = _pec_short_cell("fine", "false")
    db, detail = settling_db_from_port_records(
        _rebuild_solve(c["settling_records"][0]), return_detail=True)
    assert detail["skipped_records"] == [
        "port1/v_probe_t", "port1/v_ref_t", "port1/i_probe_t", "port1/i_ref_t"]
    assert detail["n_witnessed"] == 4
    assert detail["floor_amplitude"] == pytest.approx(
        _settling_record_floor_amplitude(c["float32_normal_min"]), rel=0, abs=0)
    assert db < -90.0


def test_a_subnormal_record_no_longer_carries_the_pass():
    """Mid rung: the witness passed at -40.85 dB on a record whose peak
    amplitude is 2.97e-40 and whose tail mean is a few hundred subnormal
    quanta. That record is out; the number now comes from the driven port's
    own records at -94.6 dB."""
    c = _pec_short_cell("mid", "false")
    assert min(c["settling_db"].values()) == pytest.approx(-40.91, abs=0.01)
    floor = _settling_record_floor_amplitude(c["float32_normal_min"])
    for call, expected in zip(c["settling_records"], (-94.621, -94.553)):
        db, detail = settling_db_from_port_records(_rebuild_solve(call),
                                                   return_detail=True)
        assert db == pytest.approx(expected, abs=0.01), detail
        assert len(detail["skipped_records"]) == 4 and detail["n_witnessed"] == 4
        # the record that used to carry the pass is one of the skipped four
        worst_rec = max(call, key=lambda r: r["db"])
        assert worst_rec["db"] == pytest.approx(-40.9, abs=0.1), worst_rec
        assert _settling_db_for_record(worst_rec["peak"], worst_rec["end"],
                                       floor) is None
        assert (f"port{worst_rec['port_index']}/{worst_rec['record']}"
                in detail["skipped_records"])


def test_normal_range_far_port_records_are_kept_and_the_cell_does_not_move():
    """Control, and the reason the floor is not simply "the far port": at the
    coarse rung the same far-port records are ordinary float32 (peak
    amplitudes 3.15e-20 / 5.5e-23). Nothing is skipped and the recorded-cell
    gate stays unchanged. #919 normalizes power before reduction to avoid
    overflow/underflow; compare its arithmetic to an independent high-
    precision ratio, not the last bit of the superseded operation order.
    """
    from decimal import Decimal, localcontext

    c = _pec_short_cell("coarse", "false")
    for call, port in zip(c["settling_records"], ("left", "right")):
        cfgs = _rebuild_solve(call)
        db, detail = settling_db_from_port_records(cfgs, return_detail=True)
        assert detail["skipped_records"] == [] and detail["n_witnessed"] == 8
        references = []
        tail_max = 0
        # Raw stored samples -> unscaled squared power in Decimal. This
        # oracle does not share the production normalization or reduction.
        with localcontext() as context:
            context.prec = 60
            for cfg in cfgs:
                for name in ("v_probe_t", "v_ref_t", "i_probe_t", "i_ref_t"):
                    raw = np.asarray(getattr(cfg, name))
                    tail = max(1, len(raw) // 10)
                    tail_max = max(tail_max, tail)
                    peak = Decimal.from_float(float(np.max(np.abs(raw))))**2
                    end = sum((Decimal.from_float(float(x))**2 for x in raw[-tail:]),
                              Decimal(0)) / Decimal(tail)
                    references.append(Decimal(10) * (end / peak).log10())
            reference = float(max(references))
        # Positive terms have no cancellation: a serial tail reduction
        # plus the surrounding divisions/square is bounded by gamma_(N+8).
        # Convert relative ratio error to dB. The extra two ULPs are an
        # explicit platform log/final-rounding allowance, not an IEEE
        # guarantee about the accuracy of every platform's libm.
        unit_roundoff = np.finfo(float).eps / 2
        gamma = (tail_max + 8) * unit_roundoff / (1 - (tail_max + 8) * unit_roundoff)
        roundoff_db = 10 / np.log(10) * (-np.log1p(-gamma)) + 2 * abs(np.spacing(reference))
        assert abs(db - reference) <= roundoff_db
        assert settling_verdict(db) == settling_verdict(reference) == settling_verdict(_legacy_worst(cfgs))
        assert db == pytest.approx(c["settling_db"][port], abs=0.01)


def test_a_run_with_no_witnessable_record_is_nan_and_loud_not_a_pass():
    """The all-skipped case, on real records: the mid rung's four far-port
    records alone. NaN is the "no witness value" state, and NaN <= -40 dB is
    False, so it cannot pass a gate -- but the aggregate warner skips NaN by
    design, so the witness itself has to say the coverage is gone."""
    c = _pec_short_cell("mid", "false")
    far = [r for r in c["settling_records"][0] if r["port_index"] == 1]
    assert len(far) == 4
    cfgs = [_Records({r["record"]: _rebuild_record(r["peak"], r["end"], r["n_steps"])
                      for r in far})]
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        db, detail = settling_db_from_port_records(cfgs, return_detail=True)
    assert np.isnan(db)
    assert not bool(db <= _SETTLING_WITNESS_DB), "NaN must not read as a pass"
    assert detail["n_witnessed"] == 0 and len(detail["skipped_records"]) == 4
    hot = [w for w in caught if "NO COVERAGE" in str(w.message)]
    assert len(hot) == 1, [str(w.message) for w in caught]
    msg = str(hot[0].message)
    assert "must NOT be read as a pass" in msg and "port0/i_probe_t" in msg, msg


def test_synthetic_all_subnormal_record_set_is_refused():
    """The same decision without the fixture: every record a subnormal ramp."""
    tiny32 = float(np.finfo(np.float32).tiny)
    n = 200
    per = {}
    for k, name in enumerate(("v_probe_t", "v_ref_t", "i_probe_t", "i_ref_t")):
        a = np.zeros(n, dtype=np.float32)
        a[0] = np.float32(tiny32 / (10.0 ** (k + 1)))
        a[-20:] = np.float32(tiny32 / (10.0 ** (k + 4)))
        per[name] = a
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        db = settling_db_from_port_records([_Records(per)])
    assert np.isnan(db) and not bool(db <= _SETTLING_WITNESS_DB)
    assert [w for w in caught if "NO COVERAGE" in str(w.message)]


# ===========================================================================
# 5. run() lane (#885) — the witness on Result, absent-not-NaN
# ===========================================================================
#
# The gap this closes, measured: `Result` carried no settling field at all,
# so a campaign driver read `getattr(result, "settling_db", np.nan)`, wrote
# `nan` into its artifact for a 282,000-step far-field run, and on a second
# experiment compared that `nan` to a "-40 dB or INCONCLUSIVE" guard. `nan`
# is not above -40, the comparison went the wrong way, and 3 hours of GPU
# came back INCONCLUSIVE for an instrument reason while the same run's
# S-parameter lane recorded -156 / -154 dB.
#
# Two-thirds of these tests need no FDTD: the witness is host-side
# post-processing of `result.time_series`, so a hand-built record exercises
# the arithmetic and the absent/NaN policy directly.

from rfx.api._sparams import settling_verdict  # noqa: E402
from rfx.api._spec import Result  # noqa: E402
from rfx.sources.waveguide_port import (  # noqa: E402
    settling_db_from_named_records,
)


def _run_sim(probe=True, dft=False, probe_position=(0.002, 0.002, 0.003)):
    """Tiny open-domain box: one soft Ez source, optionally one probe."""
    sim = Simulation(freq_max=10e9, domain=(0.004, 0.004, 0.004), dx=1e-3,
                     boundary="cpml", cpml_layers=4)
    sim.add_source((0.002, 0.002, 0.002), "ez")
    if dft:
        sim.add_dft_plane_probe(axis="z", coordinate=0.002, component="ez",
                                n_freqs=3)
    if probe:
        sim.add_probe(probe_position, "ez")
    return sim


def _settling_warnings(caught):
    return [w for w in caught if "settling" in str(w.message)]


def _no_nan_anywhere(witness):
    """No float anywhere in the witness dict is NaN (the #885 policy)."""
    def _floats(obj):
        if isinstance(obj, dict):
            for v in obj.values():
                yield from _floats(v)
        elif isinstance(obj, (list, tuple)):
            for v in obj:
                yield from _floats(v)
        elif isinstance(obj, float):
            yield obj
    return not any(math.isnan(v) for v in _floats(witness))


def test_settled_run_carries_a_finite_witness_that_passes():
    """(a) A decayed record: finite settling_db, verdict "pass", and the
    value is the end/peak arithmetic recomputed from the probe record."""
    sim = _run_sim()
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        result = sim.run(n_steps=800, skip_preflight=True)

    assert result.settling_db is not None
    assert math.isfinite(result.settling_db)
    assert settling_verdict(result.settling_db) == "pass"
    assert result.settling_witness["status"] == "measured"
    assert result.settling_witness["route"] == "probe_records"
    assert _no_nan_anywhere(result.settling_witness)
    assert not _settling_warnings(caught), [
        str(w.message) for w in _settling_warnings(caught)]

    # Recompute independently from the returned record: peak power over the
    # whole series, mean power over the last tenth.
    record = np.asarray(result.time_series)[:, 0].astype(np.float64)
    power = record ** 2
    tail = max(1, power.shape[0] // 10)
    expected = 10.0 * np.log10(
        (float(power[-tail:].mean()) + float(np.finfo(float).tiny))
        / (float(power.max()) + float(np.finfo(float).tiny)))
    assert result.settling_db == pytest.approx(expected, abs=1e-9)
    assert result.settling_witness["per_record_db"]["probe0(ez)"] == \
        pytest.approx(expected, abs=1e-9)


def test_truncated_run_fails_the_witness_and_warns():
    """(b) The same fixture stopped while it is still ringing, with a
    field-DFT plane requested — the claims-bearing open-domain number the
    settling rule governs."""
    sim = _run_sim(dft=True)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        result = sim.run(n_steps=60, skip_preflight=True)

    assert settling_verdict(result.settling_db) == "fail"
    assert result.settling_db > _SETTLING_WITNESS_DB
    hot = [w for w in _settling_warnings(caught)
           if "witness FAILED" in str(w.message)]
    assert len(hot) == 1, [str(w.message) for w in caught]
    msg = str(hot[0].message)
    assert "probe0(ez)" in msg and "n_steps=60" in msg, msg
    assert "NTFF far" in msg and "Harminv" in msg, msg


def test_a_bare_probe_run_gets_the_number_without_a_second_lecture():
    """The same truncated record with NO NTFF and no field DFT: the witness
    is still on the result, and the run() lane stays silent because the #332
    envelope advisory already speaks for a bare probe run — two lines about
    one record in two different measures is the #470 flooding class."""
    sim = _run_sim()
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        result = sim.run(n_steps=60, skip_preflight=True)

    assert settling_verdict(result.settling_db) == "fail"
    assert result.settling_witness["status"] == "measured"
    assert not _settling_warnings(caught), [
        str(w.message) for w in _settling_warnings(caught)]


def test_probeless_run_is_absent_not_nan():
    """(c) No probe: settling_db is None, status "absent", no NaN anywhere,
    and the absent-warning fires ONLY when NTFF / field-DFT was requested."""
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        quiet = _run_sim(probe=False).run(n_steps=200, skip_preflight=True)
    assert quiet.settling_db is None
    assert quiet.settling_witness["status"] == "absent"
    assert quiet.settling_witness["route"] is None
    assert settling_verdict(quiet.settling_db) == "absent"
    assert _no_nan_anywhere(quiet.settling_witness)
    assert "add_probe" in quiet.settling_witness["reason"]
    # a run that asks for no open-domain DFT number is not lectured
    assert not _settling_warnings(caught), [
        str(w.message) for w in _settling_warnings(caught)]

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        dft = _run_sim(probe=False, dft=True).run(n_steps=200,
                                                  skip_preflight=True)
    assert dft.settling_db is None
    absent = [w for w in _settling_warnings(caught)
              if "no ring-down settling witness" in str(w.message)]
    assert len(absent) == 1, [str(w.message) for w in caught]
    assert "unguarded" in str(absent[0].message)


def test_a_missing_witness_can_never_read_as_a_pass():
    """The #885 defect in its original shape: the comparison that turned a
    missing witness into a pass, now routed through the one helper."""
    assert settling_verdict(None) == "absent"
    assert settling_verdict(float("nan")) == "absent"
    assert settling_verdict(float("-inf")) == "absent"
    assert settling_verdict(_SETTLING_WITNESS_DB) == "pass"
    assert settling_verdict(_SETTLING_WITNESS_DB + 1e-9) == "fail"
    # the shape the campaign driver used
    class _Old:
        pass
    assert settling_verdict(getattr(_Old(), "settling_db", None)) == "absent"


def test_preflight_says_the_witness_will_be_absent():
    """(d) Input-side: NTFF/field-DFT requested with no probe registered."""
    report = _run_sim(probe=False, dft=True).preflight()
    hits = report.by_code("settling_witness_will_be_absent")
    assert hits, f"codes: {[i.code for i in report]}"
    assert "no point probe" in str(hits[0])
    quiet = _run_sim(probe=True, dft=True).preflight()
    assert not quiet.by_code("settling_witness_will_be_absent")
    none_requested = _run_sim(probe=False, dft=False).preflight()
    assert not none_requested.by_code("settling_witness_will_be_absent")


def test_an_underflowed_probe_record_is_skipped_and_named():
    """(e) The #869 class on the run() lane: an all-zero record must be
    SKIPPED and reported by name, never scored as a 0.00 dB hard fail.

    Hand-built records — no FDTD needed, the witness is host-side."""
    sim = _run_sim()
    sim.add_probe((0.002, 0.002, 0.001), "ez")  # probe1
    n = 400
    live = np.zeros((n, 2), dtype=np.float32)
    live[:, 0] = np.float32(1.0) * np.exp(-np.arange(n) / 20.0)
    # column 1 stays exactly zero: the underflowed-record class

    class _FakeResult:
        time_series = live

    db, witness = sim._run_settling_witness(_FakeResult())
    assert witness["status"] == "measured"
    assert witness["skipped_records"] == ["probe1(ez)"]
    assert "probe1(ez)" not in witness["per_record_db"]
    assert db == pytest.approx(witness["per_record_db"]["probe0(ez)"])
    assert db < 0.0 and db != pytest.approx(0.0)

    # every record underflowed -> absent (and loud), not a 0 dB fail
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")

        class _AllZero:
            time_series = np.zeros((n, 2), dtype=np.float32)

        db2, witness2 = sim._run_settling_witness(_AllZero())
    assert db2 is None and witness2["status"] == "absent"
    assert settling_verdict(db2) == "absent"
    assert _no_nan_anywhere(witness2)
    assert sorted(witness2["skipped_records"]) == ["probe0(ez)", "probe1(ez)"]
    assert [w for w in caught if "NO COVERAGE" in str(w.message)]


def test_one_arithmetic_shared_by_both_lanes():
    """The run() lane and the S-parameter lanes score a record identically —
    same tail window, same underflow floor, one implementation."""
    n = 300
    rec = (np.exp(-np.arange(n) / 30.0)).astype(np.float32)
    direct = settling_db_from_named_records([("probe0(ez)", rec)])
    sim = _run_sim()

    class _FakeResult:
        time_series = rec[:, None]

    db, _ = sim._run_settling_witness(_FakeResult())
    assert db == pytest.approx(direct)


def test_a_driver_internal_run_does_not_double_fire():
    """The MSL S-matrix driver drives each port through ``sim.run()``. That
    record's ring-down is judged by ``MSLSMatrixResult.settling_db``, which
    already enforces the bar through the shared warner, so the run() lane
    must stay silent there — two warnings for one record is the #470
    advisory-flooding class. The witness is still attached.

    Exercised on the attach path directly: the MSL FDTD runs that motivate
    this live in section 1 and cost minutes; the decision does not."""
    sim = _run_sim(dft=True)
    n = 200
    record = np.ones((n, 1), dtype=np.float32)  # never rings down -> "fail"

    res = Result(state=None, time_series=record, s_params=None, freqs=None)

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        loud = sim._attach_run_settling_witness(res, n_steps=n)
    assert settling_verdict(loud.settling_db) == "fail"
    assert len(_settling_warnings(caught)) == 1

    sim._internal_probe_indices = {0}
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        quiet = sim._attach_run_settling_witness(res, n_steps=n)
    assert quiet.settling_witness["status"] == "absent"
    assert quiet.settling_db is None
    assert not _settling_warnings(caught), [
        str(w.message) for w in _settling_warnings(caught)]


def test_realized_conductor_planes_equal_the_declaration():
    """Build-time witness (no solve) for the #931 ownership contract.

    Ground and trace are SHEETS, each with exactly one wall plane on its
    own laminate face,
    with the normal Ez edge through it left live. Drawn one cell thick it
    was a volume: two walls, and the Ez edge between them shorted. This
    assertion is what keeps the declaration and the realization the same
    statement.
    """
    sim = _msl_thru()
    assert_sheet_planes(sim, 2, [0., 0.0008], what="MSL thru ground and trace")
    assert_wall_planes(sim, 2, [0., 0.0008], what="MSL thru ground and trace")
